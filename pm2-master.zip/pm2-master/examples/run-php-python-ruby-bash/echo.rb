
while 1 do
  puts "lol"
  sleep 1
end

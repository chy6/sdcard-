function x() {
  x();
}
x();

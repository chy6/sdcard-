
setInterval(function() {
  new Error('toto');
}, 10);

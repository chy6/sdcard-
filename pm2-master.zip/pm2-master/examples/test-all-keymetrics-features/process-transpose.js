
var Probe = require('@pm2/io').probe();

var counter = 0;

// var metric = Probe.transpose({
//   name : 'data-flow',
//   data : function() {
//     return {
//       a : {
//         b  : {
//           data : 'textflow',
//           array : [ 'yes', 'it', 'is' ]
//         }
//       }
//     }
//   }
// });

setInterval(function() {
}, 100);

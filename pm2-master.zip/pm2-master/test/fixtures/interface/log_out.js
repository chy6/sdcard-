

console.log('outmsg');

console.error('errmsg');

setInterval(function() {}, 100);

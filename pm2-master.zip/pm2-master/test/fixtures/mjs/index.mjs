import {test} from './test'

test();

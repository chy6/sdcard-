
setInterval(function() {
  console.log('Worker finished his job');
}, 1000);


console.log('HEY!');

setTimeout(function() {
  process.exit(1);
}, 3000);

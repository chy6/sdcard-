while True:
    print 'hello'

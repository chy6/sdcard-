<!--
Your issue may already be reported!
Please search on the [issue tracker](https://github.com/Unitech/pm2/search?type=Issues) before creating one.
-->

## What's going wrong?

## How could we reproduce this issue?

## Supporting information

<!--
Please run the following command (available on PM2 >= 2.6)
-->
```
$ pm2 report
```
